# Urban Open World — prototype Android

Prototype original de jeu mobile 2D en vue du dessus, avec commandes tactiles et ambiance urbaine. Ce n'est pas GTA et ce n'est pas encore un jeu 3D complet.

## Compiler en ligne depuis un téléphone Android (sans ordinateur)

Le dossier contient un workflow GitHub Actions (`.github/workflows/build-apk.yml`) qui compile automatiquement l'APK.

1. Téléchargez ce ZIP et décompressez-le sur votre téléphone avec l'application Fichiers ou un gestionnaire d'archives.
2. Dans un navigateur, créez/connectez-vous à un compte GitHub sur https://github.com.
3. Créez un nouveau dépôt, par exemple `urban-open-world`, et choisissez **Public** (plus simple pour débuter). Ne cochez pas l'ajout automatique d'un README ou d'autres fichiers.
4. Téléversez le **contenu** du dossier `UrbanOpenWorldAndroid` dans le dépôt, en conservant le dossier caché `.github/workflows/build-apk.yml`. Le plus simple est d'utiliser GitHub dans le navigateur en mode bureau; selon le navigateur, le téléversement des dossiers cachés peut être difficile.
5. Ouvrez l'onglet **Actions**, sélectionnez **Build Android APK**, puis **Run workflow** si le workflow ne démarre pas automatiquement après l'envoi des fichiers.
6. Attendez que l'exécution soit terminée avec une coche verte. Ouvrez l'exécution, descendez à **Artifacts**, puis téléchargez `UrbanOpenWorld-debug-apk`.
7. Décompressez l'archive d'artefact téléchargée et touchez `app-debug.apk` pour l'installer. Android peut demander d'autoriser l'installation depuis votre navigateur ou votre application Fichiers : n'autorisez cette option que pour ce fichier que vous venez de compiler.

**Important :** un APK de débogage n'est pas signé pour une publication sur Play Store. La compilation nécessite Internet et peut prendre quelques minutes. Le dépôt public rend le code visible publiquement; n'y mettez aucun mot de passe ou renseignement personnel.

## Contenu du prototype
- Joystick tactile pour déplacer le personnage.
- Bouton RUN pour courir.
- Bouton CAR / EXIT pour entrer/sortir d'un véhicule de démonstration.
- Bouton ACT et mini-carte visuelle.

## Limites
C'est une démo 2D, pas un jeu GTA 3D complet. Les missions, sons, sauvegardes, conduite avancée et combats ne sont pas développés.
