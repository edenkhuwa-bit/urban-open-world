package com.example.urbanopenworld;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

public class GameView extends View {
    private final Paint p = new Paint(3);
    private float px = 0, py = 0, joyX, joyY;
    private float moveX = 0, moveY = 0;
    private boolean running = false, inCar = false;
    private int screenW, screenH;
    private long last = System.currentTimeMillis();
    private String toast = "EXPLORE LA VILLE";
    private long toastUntil = System.currentTimeMillis() + 2500;
    private final float worldScale = 1f;

    public GameView(Context c) { super(c); setFocusable(true); }

    private void fill(Canvas c, int color, float l, float t, float r, float b) {
        p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRect(l,t,r,b,p);
    }
    private void circle(Canvas c, int color, float x, float y, float radius) {
        p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawCircle(x,y,radius,p);
    }
    private void text(Canvas c, String s, float x, float y, float size, int color) {
        p.setColor(color); p.setTextSize(size); p.setTypeface(android.graphics.Typeface.create("sans-serif-condensed", 1)); c.drawText(s,x,y,p);
    }
    private void round(Canvas c, int color, float l,float t,float r,float b,float rad) {
        p.setColor(color); p.setStyle(Paint.Style.FILL); c.drawRoundRect(new RectF(l,t,r,b),rad,rad,p);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        screenW = getWidth(); screenH = getHeight();
        if (px == 0 && py == 0) { px = screenW * .5f; py = screenH * .52f; }
        long now = System.currentTimeMillis();
        float dt = Math.min(.04f, (now-last)/1000f); last = now;
        float speed = (running ? 235f : 135f) * dt;
        px += moveX * speed; py += moveY * speed;
        px = Math.max(40, Math.min(screenW-40, px));
        py = Math.max(40, Math.min(screenH-40, py));

        // Sky, grass verges, asphalt roads and city blocks create a lightweight top-down game scene.
        fill(c, Color.rgb(81,128,85), 0,0,screenW,screenH);
        float roadY = screenH*.48f;
        fill(c, Color.rgb(62,67,73), 0, roadY-screenH*.16f, screenW, roadY+screenH*.16f);
        fill(c, Color.rgb(62,67,73), screenW*.18f, 0, screenW*.31f, screenH);
        fill(c, Color.rgb(212,203,166), 0, roadY-screenH*.17f, screenW, roadY-screenH*.16f);
        fill(c, Color.rgb(212,203,166), 0, roadY+screenH*.16f, screenW, roadY+screenH*.17f);
        // Road lane dashes
        p.setColor(Color.rgb(244,211,95)); p.setStrokeWidth(4);
        for(int i=-1;i<9;i++) {
            float x = i*screenW/7f - (px-screenW*.5f)*.12f;
            c.drawLine(x,roadY,x+screenW*.045f,roadY,p);
        }
        // Buildings, with small windows
        drawBuilding(c, screenW*.035f, screenH*.10f, screenW*.12f, screenH*.20f, Color.rgb(172,144,119));
        drawBuilding(c, screenW*.36f, screenH*.06f, screenW*.14f, screenH*.25f, Color.rgb(123,137,148));
        drawBuilding(c, screenW*.69f, screenH*.07f, screenW*.16f, screenH*.22f, Color.rgb(185,161,132));
        drawBuilding(c, screenW*.84f, screenH*.65f, screenW*.12f, screenH*.20f, Color.rgb(145,139,126));
        // Palm-like trees
        for(int i=0;i<7;i++) {
            float tx = (i*screenW/6f + screenW - (px*.14f)%screenW);
            tx %= screenW;
            circle(c, Color.rgb(105,69,43), tx, screenH*.27f, 5);
            circle(c, Color.rgb(30,95,55), tx, screenH*.255f, 15);
        }
        // Moving traffic
        drawCar(c, screenW*.42f + (float)Math.sin(now/1500.0)*screenW*.12f, roadY-screenH*.08f, Color.rgb(205,75,55), false);
        drawCar(c, screenW*.73f - (float)Math.sin(now/1800.0)*screenW*.12f, roadY+screenH*.07f, Color.rgb(43,49,57), true);
        // Player
        if (inCar) {
            drawCar(c, px, py, Color.rgb(255,191,71), true);
        } else {
            circle(c, Color.argb(90,0,0,0), px+3, py+7, 16);
            circle(c, Color.rgb(48,55,65), px, py+5, 11);
            circle(c, Color.rgb(232,184,140), px, py-10, 8);
            round(c, Color.rgb(44,128,174), px-9,py-2,px+9,py+12,4);
        }
        // HUD
        round(c, Color.argb(210,12,20,28), 16,14,210,75,15);
        text(c,"URBAN DISTRICT",29,38,18,Color.WHITE);
        text(c,"$ 2 500   |   HP 100",29,60,14,Color.rgb(112,231,139));
        round(c, Color.argb(205,12,20,28), screenW-145,14,screenW-16,61,14);
        text(c,"MISSION 01",screenW-132,34,15,Color.rgb(255,205,94));
        text(c,"Explorer",screenW-132,51,13,Color.WHITE);
        // Minimap
        round(c, Color.argb(210,10,18,24), screenW-106,screenH-106,screenW-16,screenH-16,14);
        fill(c, Color.rgb(86,98,103), screenW-98,screenH-98,screenW-24,screenH-24);
        fill(c, Color.rgb(203,196,161), screenW-72,screenH-98,screenW-62,screenH-24);
        fill(c, Color.rgb(203,196,161), screenW-98,screenH-65,screenW-24,screenH-57);
        circle(c, Color.rgb(255,205,94), screenW-61,screenH-62,4);
        // Touch control panel
        float baseX=92, baseY=screenH-92;
        circle(c, Color.argb(110,8,12,17),baseX,baseY,61);
        circle(c, Color.argb(210,210,220,224),baseX+moveX*24,baseY+moveY*24,20);
        drawButton(c, screenW-82,screenH-91,35,"RUN",Color.rgb(41,150,95));
        drawButton(c, screenW-165,screenH-77,31,inCar?"EXIT":"CAR",Color.rgb(52,119,180));
        drawButton(c, screenW-165,screenH-151,31,"ACT",Color.rgb(191,76,59));
        if(now < toastUntil) {
            round(c,Color.argb(205,12,20,28),screenW*.35f,screenH*.13f,screenW*.65f,screenH*.20f,12);
            text(c,toast,screenW*.38f,screenH*.175f,17,Color.WHITE);
        }
        postInvalidateDelayed(16);
    }

    private void drawBuilding(Canvas c,float x,float y,float w,float h,int color) {
        round(c,Color.argb(65,0,0,0),x+7,y+7,x+w+7,y+h+7,5);
        round(c,color,x,y,x+w,y+h,5);
        p.setColor(Color.rgb(234,204,136));
        float winW=Math.max(5,w*.13f), winH=Math.max(5,h*.12f);
        for(float xx=x+10;xx<x+w-winW;xx+=winW+9)
            for(float yy=y+10;yy<y+h-winH;yy+=winH+9)
                c.drawRect(xx,yy,xx+winW,yy+winH,p);
    }
    private void drawCar(Canvas c,float x,float y,int color,boolean reverse) {
        c.save(); c.rotate(reverse?180:0,x,y);
        round(c,Color.rgb(25,28,31),x-24,y-12,x+24,y+12,7);
        round(c,color,x-20,y-10,x+20,y+10,6);
        round(c,Color.rgb(72,106,126),x-9,y-8,x+9,y+8,3);
        fill(c,Color.rgb(242,232,186),x+16,y-7,x+21,y-3);
        c.restore();
    }
    private void drawButton(Canvas c,float x,float y,float r,String label,int color) {
        circle(c,Color.argb(100,0,0,0),x,y,r+3);
        circle(c,Color.argb(220, color==Color.rgb(41,150,95)?41:color==Color.rgb(52,119,180)?52:191,
                color==Color.rgb(41,150,95)?150:color==Color.rgb(52,119,180)?119:76,
                color==Color.rgb(41,150,95)?95:color==Color.rgb(52,119,180)?180:59),x,y,r);
        p.setColor(Color.WHITE); p.setTextSize(label.length()>3?10:13); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        float tw=p.measureText(label); c.drawText(label,x-tw/2,y+4,p);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float x=e.getX(), y=e.getY();
        int action=e.getActionMasked();
        if(action==MotionEvent.ACTION_DOWN || action==MotionEvent.ACTION_MOVE) {
            if(x<screenW*.30f && y>screenH*.55f) {
                joyX=(x-92)/58f; joyY=(y-(screenH-92))/58f;
                float mag=(float)Math.sqrt(joyX*joyX+joyY*joyY);
                if(mag>1){joyX/=mag;joyY/=mag;}
                moveX=joyX; moveY=joyY;
            } else {
                moveX=0; moveY=0;
                if(action==MotionEvent.ACTION_DOWN) {
                    if(x>screenW-125 && y>screenH-140) { running=!running; toast=running?"COURSE ACTIVEE":"MARCHE"; toastUntil=System.currentTimeMillis()+1200; }
                    else if(x>screenW-210 && y>screenH-125 && y<screenH-35) { inCar=!inCar; toast=inCar?"VEHICULE : CONDUITE":"A PIED"; toastUntil=System.currentTimeMillis()+1600; }
                    else if(x>screenW-210 && y>screenH-195 && y<screenH-110) { toast="OBJECTIF : REJOINS LE POINT JAUNE"; toastUntil=System.currentTimeMillis()+1800; }
                }
            }
            invalidate(); return true;
        }
        if(action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_CANCEL) {
            moveX=0; moveY=0; invalidate(); return true;
        }
        return true;
    }
}
